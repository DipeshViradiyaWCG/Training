exports.add_product = function (req, res, next) {
    res.status(200).json({msg : "Hello API user..."});
};